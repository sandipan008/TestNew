package com.proj.Sportathon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportathonApplicationTests {

	@Test
	void contextLoads() {
	}

}

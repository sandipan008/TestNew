package com.proj.Sportathon.entities;


import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "team_details")
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "team_name")
    private String teamName;

   
    @Column(name = "captain_sapId")
    private String captainSapId;
    
    @Column(name = "captain_name")
    private String captainName;

    @Column(name = "cap_gender")
    private String capgender;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "team_id",referencedColumnName="id")
    private List<TeamMember> teamMembers;

    @Column(name = "location")
    private String location;

    @Column(name = "sport")
    private String sport;

 
}


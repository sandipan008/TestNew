package com.proj.Sportathon.customexceptions;

public class ValueNotPresentException extends Exception {

public ValueNotPresentException() {
		
	}
	public ValueNotPresentException(String str) {
		super(str);
	}
	
}

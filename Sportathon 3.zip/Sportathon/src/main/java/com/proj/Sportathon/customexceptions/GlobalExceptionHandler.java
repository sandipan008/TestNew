package com.proj.Sportathon.customexceptions;

//import com.proj.user.payload.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice      //to make this centralized exception handler
public class GlobalExceptionHandler {
    @ExceptionHandler({WrongValueException.class,ValueNotPresentException.class,NullValueException.class,DuplicateValueException.class})
    public ResponseEntity<?>  handlerResourceNotFoundException(Exception ex){
        String message = ex.getMessage();
//        System.out.println(message);
//        ApiResponse response= ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
//        return message;
    }
    
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<String>  handlerResourceNotFoundException(Exception ex){
//        String message = ex.getMessage();
////        System.out.println(message);
////        ApiResponse response= ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
//        return new ResponseEntity<String>(message,HttpStatus.NOT_FOUND);
////        return message;
//    }
}

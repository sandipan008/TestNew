package com.proj.Sportathon.customexceptions;

public class WrongValueException extends Exception {
	
	public WrongValueException() {

	}
	
	public WrongValueException(String str) {
		super(str);
		System.out.println("exception");
		
	}

}

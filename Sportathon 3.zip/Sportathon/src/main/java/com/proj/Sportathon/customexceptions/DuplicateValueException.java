package com.proj.Sportathon.customexceptions;

public class DuplicateValueException extends Exception {
	
	public DuplicateValueException() {

	}
	
	public DuplicateValueException(String str) {
		super(str);
	}
	
}

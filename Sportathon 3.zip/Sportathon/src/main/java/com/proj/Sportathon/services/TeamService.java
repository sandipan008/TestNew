package com.proj.Sportathon.services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.Sportathon.customexceptions.DuplicateValueException;
import com.proj.Sportathon.customexceptions.NullValueException;
import com.proj.Sportathon.customexceptions.ValueNotPresentException;
import com.proj.Sportathon.customexceptions.WrongValueException;
import com.proj.Sportathon.entities.Team;
import com.proj.Sportathon.entities.TeamMember;
import com.proj.Sportathon.repositories.TeamRepository;
import com.proj.Sportathon.response.Response;

@Service
public class TeamService {
	
	@Autowired
	private TeamRepository teamRepository;


    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    public Optional<Team> getTeamById(Long id) {
        return teamRepository.findById(id);
    }

    public Team createTeam(Team team) throws Exception {
    	validateSapIdLength(team);
    	validateUniqueTeamNameForSport(team);
    	validateSapIdAndCaptainSapIdUniquenessForSport(team);
        return teamRepository.save(team);
    }
        
    public Team updateTeam(Long id, Team team) {
        team.setId(id);
        return teamRepository.save(team);
    }

    public Response deleteTeam(Long id) throws Exception {
        if (!teamRepository.existsById(id)) {
            throw new ValueNotPresentException("Team with the specified ID does not exist");
        }
        
        teamRepository.deleteById(id);
        
        return new Response("Team deleted successfully");
    }
    
    private void validateSapIdLength(Team team) throws Exception{
        String captainSapId = team.getCaptainSapId();
        String errorMessage = "The SapId must have a length of 8 characters.";
        
        if(captainSapId==null || captainSapId.length()==0) {
        	throw new NullValueException("Captain SapId cannot be null or empty");
        }
        
        if ( captainSapId.length()!=8) {

        	throw new WrongValueException(errorMessage);
        }
        
        List<TeamMember> teamMembers = team.getTeamMembers();
        if (teamMembers != null) {
            for (TeamMember member : teamMembers) {
                String sapId = member.getSapId();

                if(sapId==null || sapId.length()==0) {
                	throw new NullValueException("TeamMembers SapId cannot be null or empty");
                }
                if (sapId.length()!=8) {
                	System.out.println(sapId+"SapId length "+sapId.length());
                    throw new WrongValueException(errorMessage);
                }
            }
        }
    }
    
    
    //it will check teamName is unique for similar sport
    private void validateUniqueTeamNameForSport(Team team) throws Exception {
      String sport = team.getSport();
      String teamName = team.getTeamName();
      if(teamName==null || teamName.length()==0) {
      	throw new NullValueException("TeamName cannot be null or empty");
      }
      if(sport==null || sport.length()==0) {
      	throw new NullValueException("Sports name cannot be null or empty");
      }
      if(teamRepository.existsByTeamNameAndSport(teamName,sport)) {   //this method is present in repo by default , we just need to declare this method in the repo
    	  throw new DuplicateValueException("Team name must be unique for similar Sport");
      }
      
      
  }
    
    
    private void validateSapIdAndCaptainSapIdUniquenessForSport(Team team) throws Exception{
    	String errorMessage = "The SAP ID and Captain's SAP ID must be unique for a similar sport.";
    	String sport = team.getSport();
    	String captainSapId = team.getCaptainSapId();
    	List<TeamMember> teamMembers = team.getTeamMembers();

    	Map<String, Boolean> map = new HashMap<>();    
    	
    	if(teamRepository.existsBySportAndCaptainSapId(sport, captainSapId)) {   //this method is present in repo by default , we just need to declare this method in the repo
	    	System.out.println("inside the method");  
    		throw new DuplicateValueException(errorMessage);
	      }
    	//it is counting the sapId , if sapId count exceeds 1 then it will be duplicate and throw exception
    	for(int i=0;i<teamMembers.size();i++) {
    		String teamMemberSapId = teamMembers.get(i).getSapId();
    		
    		if(teamMemberSapId.equals(captainSapId)|| map.containsKey(teamMembers.get(i).getSapId())) {
    			throw new DuplicateValueException(errorMessage);
    		}
    		else {
    			map.put(teamMemberSapId, true);
    		}
    	}
    }
  
}

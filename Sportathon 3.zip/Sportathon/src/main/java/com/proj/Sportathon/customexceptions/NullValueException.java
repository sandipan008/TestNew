package com.proj.Sportathon.customexceptions;

public class NullValueException extends Exception {
	public NullValueException() {

	}

	public NullValueException(String str) {
		super(str);
	}
}

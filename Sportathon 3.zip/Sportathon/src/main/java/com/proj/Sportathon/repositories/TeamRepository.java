package com.proj.Sportathon.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.proj.Sportathon.entities.Team;


@Repository
public interface TeamRepository extends JpaRepository<Team,Long> {

	public boolean existsByTeamNameAndSport(String teamName,String sport);
	
//	public boolean existsBySapIdAndSport(String teamMemberSapId,String sport);

//	public boolean existsByCaptainSapIdAndSport(String captainSapId, String sport);


	public boolean existsBySportAndCaptainSapId(String sport, String captainSapId);


}

package com.proj.Sportathon.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proj.Sportathon.entities.TeamMember;

public interface TeamMemberRepository extends JpaRepository<TeamMember,Long> {

}
